﻿namespace Utility
{
    public static class Utility
    {
        public enum Roles { Admin, User, Shipper }
        public enum Categries { Clothing, Equipment, Food, Medication }
        public enum Status { Unvalid, Valid }
        public enum ShipStatus { InShipping, Received }
    }

}